Ripped by Hell Inspector and submitted under the name "Hawkodile"
https://www.vg-resource.com/user-39500.html

Credit is appreciated but not needed.

Thank you and Have a great day! Have fun using this model.